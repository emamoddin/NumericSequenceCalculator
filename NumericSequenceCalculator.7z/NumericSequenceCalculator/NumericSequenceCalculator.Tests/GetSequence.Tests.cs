﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NumericSequenceCalculator.Helper;

namespace NumericSequenceCalculator.Tests
{
    [TestClass]
    public class GetSequenceTest
    {
        GetSequence _getSequence;

        public GetSequenceTest()
        {
            _getSequence = new GetSequence();
        }


        [TestMethod]
        public void AllNumbers()
        {
            string sequence = _getSequence.AllNumbers(5);
            Assert.AreEqual(sequence," 1 2 3 4 5");
        }

        [TestMethod]
        public void EvenNumbers()
        {
            string sequence = _getSequence.EvenNumbers(5);
            Assert.AreEqual(sequence, " 2 4");
        }

        [TestMethod]
        public void OddNumbers()
        {
            string sequence = _getSequence.OddNumbers(5);
            Assert.AreEqual(sequence, " 1 3 5");
        }

    }

}
