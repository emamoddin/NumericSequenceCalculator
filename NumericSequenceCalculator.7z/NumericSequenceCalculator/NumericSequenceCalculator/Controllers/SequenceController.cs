﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NumericSequenceCalculator.Models;
using NumericSequenceCalculator.Helper;


namespace NumericSequenceCalculator.Controllers
{

    public class SequenceController : Controller
    {
        private IGetSequence _getSequence;  //getSequence = new GetSequence();

        public SequenceController(IGetSequence getSequence)
        {
            _getSequence = getSequence;
        }


        /// <summary>
        /// Get Display sequences as per requirements.
        /// </summary>
        /// <returns></returns>
        /// <param name="number"></param>
        public IActionResult DisplaySequence(int number)
        {
            try
            {
                //TODO Check if number is less than zero here.
                //Currently it checked within the method.

                //Sequence 1
                var allNumbers = _getSequence.AllNumbers(number);
                //Sequence 2
                var oddNumbers = _getSequence.OddNumbers(number);
                //Sequence 3
                var evenNumbers = _getSequence.EvenNumbers(number);
                //Sequence 4
                var allNumbersWithCharacters = _getSequence.AllNumbersWithCharacterOutput(number);


                //ViewModel populated with all 4 string sequences to be sent to the view 
                var model = new SequenceExtendedViewModel()
                {
                    AllNumbers = allNumbers,
                    OddNumbers = oddNumbers,
                    EvenNumbers = evenNumbers,
                    AllNumbersWithCharOutput = allNumbersWithCharacters
                };
                
                return View(model);

            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }
    }
}