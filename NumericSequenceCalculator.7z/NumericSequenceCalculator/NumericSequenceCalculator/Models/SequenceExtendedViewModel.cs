using System;

namespace NumericSequenceCalculator.Models
{
    public class SequenceExtendedViewModel
    {
        public string AllNumbers { get; set; }
        public string OddNumbers { get; set; }
        public string EvenNumbers { get; set; }
        public string AllNumbersWithCharOutput { get; set; }
    }
}