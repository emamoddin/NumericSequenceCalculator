﻿using System;

namespace NumericSequenceCalculator.Helper
{
    public class GetSequence : IGetSequence
    {

        /// <summary>
        /// Return all numbers.
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public string AllNumbers(int number)
        {

            string allNumbers = "";

            if (number > 0)
            {
                for (var i = 1; i <= number; i++)
                {
                    allNumbers = allNumbers + " " + i;
                }
            }

            return allNumbers;
        }

        /// <summary>
        /// Returns all odd numbers.
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public string OddNumbers(int number)
        {
            string oddNumbers = "";

            if (number > 0)
            {
                for (var i = 1; i <= number; i++)
                {
                    if (i%2 == 1)
                    {
                        oddNumbers = oddNumbers + " " + i;
                    }
                }
            }

            return oddNumbers;
        }

        /// <summary>
        /// Returns all even numbers.
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public string EvenNumbers(int number)
        {
            string evenNumbers = "";

            if (number > 0)
            {
                for (var i = 1; i <= number; i++)
                {
                    //if number divisible by 2 it will be even
                    if (i % 2 == 0)
                    {
                        evenNumbers = evenNumbers + " " + i;
                    }
                }
            }

            return evenNumbers;
        }

        /// <summary>
        /// Returns all numbers except the multipliable numbers will be replaced by character.
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public string AllNumbersWithCharacterOutput(int number)
        {

            string numSequence = "";

            if (number > 0)
            {
                for (var i = 1; i <= number; i++)
                {
                    //if number divisible by 3 replace number by character 'C'
                    if (IsDivisible(i,3))
                    {
                        numSequence = numSequence + " " + 'C';
                    }
                    //if number divisible by 5 replace number by character 'E'
                    else if (IsDivisible(i,5))
                    {
                        numSequence = numSequence + " " + 'E';
                    }
                    //if number divisible by 3 and 5 replace number by character 'Z'
                    else if (IsDivisible(i, 3) && IsDivisible(i, 5))
                    {
                        numSequence = numSequence + " " + 'Z';
                    }
                    //Numeric number as none above are matched
                    else
                    {
                        numSequence = numSequence + " " + i;
                    }
                }
            }

            return numSequence;
        }

        /// <summary>
        /// Returns true if divisible
        /// </summary>
        /// <param name="num"></param>
        /// <param name="divByNum"></param>
        /// <returns></returns>
        public bool IsDivisible(int num, int divByNum )
        {
            return (num % divByNum) == 0;
        }

    }


}
