﻿using System;

namespace NumericSequenceCalculator.Helper
{
    public interface IGetSequence
    {

        string AllNumbers(int number);

        string OddNumbers(int number);

        string EvenNumbers(int number);

        string AllNumbersWithCharacterOutput(int number);

    }


}
